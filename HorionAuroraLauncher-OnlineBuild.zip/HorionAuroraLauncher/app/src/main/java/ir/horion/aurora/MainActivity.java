package ir.horion.aurora;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, appRow; TextView clock, date, status;
    int white=Color.WHITE;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); build(); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    TextView txt(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); return t; }
    GradientDrawable bg(int color,int stroke){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(18)); if(stroke!=0)d.setStroke(dp(2),stroke); return d; }
    void build(){
        FrameLayout frame=new FrameLayout(this); frame.setBackgroundColor(Color.rgb(4,10,27));
        try { frame.setBackground(Drawable.createFromStream(getAssets().open("wallpaper.png"),null)); } catch(Exception e) { }
        // fallback background gradient if wallpaper asset isn't decoded by a device
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(52),dp(28),dp(52),dp(26));
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1); frame.addView(root,rp);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=txt("AURORA",18,Color.WHITE); logo.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        TextView sub=txt("HORION  •  SMART EXPERIENCE",10,0xFFB8C9E8); brand.addView(logo); brand.addView(sub);
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout timebox=new LinearLayout(this); timebox.setOrientation(LinearLayout.VERTICAL); timebox.setGravity(Gravity.RIGHT);
        clock=txt("--:--",25,white); date=txt("در حال بارگذاری تاریخ…",12,0xFFD8E5FA); timebox.addView(clock); timebox.addView(date); top.addView(timebox); root.addView(top);
        TextView welcome=txt("خانه‌ی شما، ساده‌تر و زیباتر",27,white); welcome.setPadding(0,dp(34),0,dp(4)); root.addView(welcome);
        TextView hint=txt("برنامه‌ای را با کنترل تلویزیون انتخاب کنید",14,0xFFD1DDF3); root.addView(hint);
        TextView section=txt("برنامه‌های شما",17,white); section.setPadding(0,dp(26),0,dp(10)); root.addView(section);
        HorizontalScrollView scroll=new HorizontalScrollView(this); scroll.setHorizontalScrollBarEnabled(false); appRow=new LinearLayout(this); appRow.setOrientation(LinearLayout.HORIZONTAL); scroll.addView(appRow); root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(142)));
        loadApps();
        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL); bottom.setPadding(0,dp(24),0,0);
        TextView settings=txt("⚙  تنظیمات",14,white); settings.setPadding(dp(18),dp(10),dp(18),dp(10)); settings.setBackground(bg(0xAA102448,0x667DBBFF)); settings.setFocusable(true); settings.setOnClickListener(v->openSettings()); bottom.addView(settings);
        TextView refresh=txt("  ↻  تازه‌سازی برنامه‌ها",13,0xFFD9E8FF); refresh.setPadding(dp(18),dp(10),dp(18),dp(10)); refresh.setFocusable(true); refresh.setOnClickListener(v->loadApps()); bottom.addView(refresh);
        status=txt("نسخه ۱٫۰  •  سبک و بدون نیاز به Google Play",11,0xFFB6C8E5); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1); sp.gravity=Gravity.RIGHT; status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); bottom.addView(status,sp); root.addView(bottom);
        frame.setFocusableInTouchMode(true); setContentView(frame); frame.requestFocus(); updateTime();
    }
    void updateTime(){ java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",new Locale("fa")); clock.setText(f.format(new Date())); java.text.SimpleDateFormat d=new java.text.SimpleDateFormat("EEEE، d MMMM yyyy",new Locale("fa")); date.setText(d.format(new Date())); }
    void loadApps(){ if(appRow==null)return; appRow.removeAllViews(); PackageManager pm=getPackageManager(); ArrayList<ResolveInfo> list=new ArrayList<>(); Intent q=new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER); for(ResolveInfo r:pm.queryIntentActivities(q,0)) { if(!r.activityInfo.packageName.equals(getPackageName())) list.add(r); }
        Collections.sort(list,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString())); int count=0;
        for(ResolveInfo r:list){ if(count++>=16)break; final String pkg=r.activityInfo.packageName; LinearLayout card=new LinearLayout(this); card.setGravity(Gravity.CENTER); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10),dp(10),dp(10),dp(8)); card.setBackground(bg(0xCC102448,0x557CB8F5)); card.setFocusable(true); card.setFocusableInTouchMode(true); card.setOnClickListener(v->{ Intent launch=pm.getLaunchIntentForPackage(pkg); if(launch!=null)try{startActivity(launch);}catch(Exception ignored){} }); ImageView icon=new ImageView(this); try{icon.setImageDrawable(r.loadIcon(pm));}catch(Exception ignored){} card.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(54))); TextView name=txt(r.loadLabel(pm).toString(),12,white); name.setGravity(Gravity.CENTER); name.setMaxLines(1); card.addView(name,new LinearLayout.LayoutParams(dp(112),dp(30))); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(126),dp(124)); cp.setMargins(0,0,dp(14),0); appRow.addView(card,cp); }
        if(list.isEmpty()){ TextView empty=txt("هنوز برنامه‌ای برای نمایش پیدا نشد",15,white); appRow.addView(empty); }
    }
    void openSettings(){ try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){ try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception ignored){} } }
    @Override public boolean onKeyDown(int key,KeyEvent e){ if(key==KeyEvent.KEYCODE_MENU){openSettings();return true;} return super.onKeyDown(key,e); }
}
